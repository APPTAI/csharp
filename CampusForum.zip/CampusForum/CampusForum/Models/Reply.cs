﻿namespace CampusForum.Models
{
    public class Reply
    {
        public int Id { get; set; }
        public string Content { get; set; }
        public string AuthorEmail { get; set; }
        public DateTime CreatedAt { get; set; }

        // 关联Post表
        public int PostId { get; set; }  // 外键
        public Post Post { get; set; }    // 导航属性
    }
}
