﻿using CampusForum.Models;

namespace CampusForum.Models
{
    public class Post
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
        public string AuthorEmail { get; set; }
        public DateTime CreatedAt { get; set; }
        public int LikeCount { get; set; }
        public ICollection<Reply> Replies { get; set; } = new List<Reply>(); // 确保初始化
    }
}

