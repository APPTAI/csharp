﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using CampusForum.Models;

namespace CampusForum.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; } // 添加用户数据表的映射

        public DbSet<Post> Posts { get; set; }
        public DbSet<Reply> Replies { get; set; }

    }
}
