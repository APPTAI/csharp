﻿using Microsoft.AspNetCore.Identity.UI.Services;
using System.Threading.Tasks;

namespace CampusForum.Services
{
    public class EmailSender : IEmailSender
    {
        public Task SendEmailAsync(string email, string subject, string htmlMessage)
        {
            // 这里只是简单输出到控制台模拟发邮件
            Console.WriteLine($"模拟发送邮件到: {email}");
            Console.WriteLine($"主题: {subject}");
            Console.WriteLine($"内容: {htmlMessage}");

            return Task.CompletedTask;
        }
    }
}
