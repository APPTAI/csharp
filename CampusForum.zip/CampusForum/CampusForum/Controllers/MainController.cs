﻿using Microsoft.AspNetCore.Mvc;

namespace CampusForum.Controllers
{
    public class MainController : Controller
    {
        public IActionResult Home()
        {
            return View();
        }
        public IActionResult Userhome()
        {
            // 从 TempData 获取用户邮箱
            var userEmail = TempData["UserEmail"] as string ?? "游客";

            // 将邮箱传递到视图
            ViewData["UserEmail"] = userEmail;

            return View();
        }
    }
}
