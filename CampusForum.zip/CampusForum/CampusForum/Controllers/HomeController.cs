﻿using Microsoft.AspNetCore.Mvc;

namespace CampusForum.Controllers
{
    public class HomeController : Controller
    {
        // 首页视图
        public IActionResult Index()
        {
            return View();
        }
    }
}
