﻿using CampusForum.Data;
using CampusForum.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace CampusForum.Controllers
{
    public class AuthController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AuthController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(string email, string password)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email);

            if (user != null && BCrypt.Net.BCrypt.Verify(password, user.PasswordHash))
            {
                HttpContext.Session.SetString("UserEmail", user.Email);  // ✅ 保存到 Session
                TempData["SuccessMessage"] = "登录成功！";

                return RedirectToAction("UserHome", "Main");
            }

            // 这里是错误提示，只有在登录失败时才会执行
            TempData["ErrorMessage"] = "邮箱或密码错误，请重试。";
            return RedirectToAction("Login");
        }
    }
}
