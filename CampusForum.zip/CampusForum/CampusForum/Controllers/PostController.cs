﻿using CampusForum.Data;
using CampusForum.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http; // 加这个
using System;
using System.Linq;
using System.Threading.Tasks;

namespace CampusForum.Controllers
{
    public class PostController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public PostController(ApplicationDbContext context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;
        }

        private string GetUserEmail()
        {
            return _httpContextAccessor.HttpContext.Session.GetString("UserEmail");
        }

        [HttpGet]
        public IActionResult Create()
        {
            ViewBag.UserEmail = GetUserEmail() ?? "游客";
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Post post)
        {
            post.CreatedAt = DateTime.Now;
            post.LikeCount = 0;
            post.AuthorEmail = GetUserEmail() ?? "游客";

            if (string.IsNullOrEmpty(post.Title) || string.IsNullOrEmpty(post.Content))
            {
                TempData["ErrorMessage"] = "标题和内容不能为空！";
                return RedirectToAction("Create");
            }

            _context.Posts.Add(post);
            await _context.SaveChangesAsync();

            return RedirectToAction("UserHome", "Main");
        }
        [HttpGet]
        public async Task<IActionResult> List()
        {
            var posts = await _context.Posts
                .Include(p => p.Replies)  // 包含回复
                .OrderByDescending(p => p.CreatedAt)  // 按时间降序排列
                .ToListAsync();

            ViewBag.UserEmail = GetUserEmail();  // 获取当前用户的邮箱
            return View(posts);  // 返回更新后的帖子列表
        }





        [HttpPost]
        public IActionResult Like(int postId)
        {
            var post = _context.Posts.FirstOrDefault(p => p.Id == postId);
            if (post == null)
            {
                return NotFound();
            }

            post.LikeCount++;
            _context.SaveChanges();

            // 返回当前点赞数给前端
            return Json(new { success = true, currentLikes = post.LikeCount });
        }




        [HttpPost]
        public async Task<IActionResult> Reply(int postId, string content)
        {
            var userEmail = GetUserEmail();
            if (userEmail == null)
            {
                TempData["ErrorMessage"] = "请登录后进行操作";
                return RedirectToAction("Login", "Auth");
            }

            var post = await _context.Posts.FirstOrDefaultAsync(p => p.Id == postId);
            if (post != null)
            {
                var reply = new Reply
                {
                    PostId = postId,
                    AuthorEmail = userEmail,
                    Content = content,
                    CreatedAt = DateTime.Now
                };

                _context.Replies.Add(reply);  // 将回复添加到数据库
                await _context.SaveChangesAsync();  // 提交到数据库

                TempData["SuccessMessage"] = "回复成功！";
            }
            else
            {
                TempData["ErrorMessage"] = "帖子不存在！";
            }

            // 重新加载帖子列表并返回
            return RedirectToAction("List");
        }     
    }
}
