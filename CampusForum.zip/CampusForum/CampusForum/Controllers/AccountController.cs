﻿using CampusForum.Data;
using CampusForum.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace CampusForum.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AccountController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Register(string email, string password, string confirmPassword)
        {
            // 判断邮箱格式是否正确
            if (string.IsNullOrEmpty(email) || !email.Contains("@"))
            {
                TempData["PopupMessage"] = "邮箱格式不正确，请确保包含 '@' 符号。";
                return RedirectToAction("Register");
            }

            // 判断密码是否符合要求（至少一个字符）
            if (string.IsNullOrEmpty(password) || password.Length < 1)
            {
                TempData["PopupMessage"] = "密码必须至少包含一个字符。";
                return RedirectToAction("Register");
            }

            // 判断密码与确认密码是否一致
            if (password != confirmPassword)
            {
                TempData["PopupMessage"] = "密码与确认密码不一致，请重新输入。";
                return RedirectToAction("Register");
            }

            // 检查邮箱是否已注册
            if (await _context.Users.AnyAsync(u => u.Email == email))
            {
                TempData["PopupMessage"] = "该邮箱已注册。";
                return RedirectToAction("Register");
            }

            // 注册新用户
            var user = new User
            {
                Email = email,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(password)
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            TempData["PopupMessage"] = "注册成功！请登录。";
            return RedirectToAction("Login", "Auth");
        }


    }
}